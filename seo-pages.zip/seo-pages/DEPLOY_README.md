# デプロイ手順

## 1. 新規ページ（16件）
以下のフォルダをリポジトリ直下（`index.html` と同じ階層）にそのままコピーしてください。既存ファイルとの重複・上書きはありません。

```
purpose/index.html
purpose/zoo/index.html
purpose/aquarium/index.html
purpose/indoor/index.html
purpose/park/index.html
purpose/museum/index.html
purpose/amusement/index.html
purpose/fruit-picking/index.html
purpose/onsen/index.html
purpose/ranch/index.html
purpose/athletic/index.html
kanagawa/yokohama/index.html
kanagawa/shonan/index.html
rainy-day/index.html
free/index.html
baby/index.html
```

## 2. sitemap.xml
同梱の `sitemap.xml` は、最新版（既存996件 + 目的別10ページ + 横浜/湘南/雨の日/無料/赤ちゃん5ページ + 季節4ページ = 1016件）です。
このファイルでリポジトリの `sitemap.xml` をそのまま置き換えてください。

## 3. robots.txt
変更不要です。

## 4. build-static-pages.js（別途お渡し済み）
都道府県ページの「人気カテゴリ」バッジのうち、動物園・水族館・室内遊び場・公園・博物館科学館・遊園地・果物狩り・温泉・牧場・アスレチック（計10ジャンル）を
`/purpose/xxx/` へのリンクに変更するパッチ済みです。それ以外のジャンル（花の名所・プール等、件数が少なく専用ページを作っていないもの）は
従来どおりリンクなしのバッジのままです（存在しないURLへのリンクを避けるため）。
リポジトリの `index.html` と `data/spots.json` を使って `node build-static-pages.js --out _build` を実行し、
`_build/tokyo/index.html` 等で「人気カテゴリ」表示を確認してから本番反映してください。
